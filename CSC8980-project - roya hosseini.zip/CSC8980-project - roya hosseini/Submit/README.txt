Run testRun for a sample with 2 images.

Feature extraction files run the file:
Segmentation.m

Helper scripts:
1. addVesselCellSizeDistFeature.m
2. addRegionSurf.m
3. findNucleiSeg.m
4. regionSegmentation.m